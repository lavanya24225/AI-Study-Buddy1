const express = require("express");
const {
  createMaterial,
  getMaterials,
  getMaterialById,
  updateMaterial,
  deleteMaterial,
} = require("../controllers/materialController");
const protect = require("../middleware/auth");
const upload = require("../middleware/upload");

const router = express.Router();

router.use(protect);

// Accepts either JSON (text-only) or multipart/form-data with a "file" field.
router.post("/upload", upload.single("file"), createMaterial);
router.get("/", getMaterials);
router.get("/:id", getMaterialById);
router.put("/:id", updateMaterial);
router.delete("/:id", deleteMaterial);

module.exports = router;
